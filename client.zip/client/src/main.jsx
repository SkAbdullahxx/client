  import React from "react";
  import ReactDOM from "react-dom/client";
  import { BrowserRouter as Router, Route, Routes, Navigate } from "react-router-dom";
  import Cookies from "js-cookie"; // Add the js-cookie package
  import "./index.css";
  import AuthPage from "./component/Auth/MotherRegister";
  import UserProfile from "./component/pages/UserProfile/own user/MotherOwnUser";
  import Home from "./component/pages/Home/Home"; // Home component that will be rendered after login
  import UserList from "./component/pages/follow and following/Alluser"; // All user component
  import Ownpost from "./component/pages/UserProfile/own user/Ownpost"; // Import your Ownpost component

  // ProtectedRoute component to check if the user is authenticated
  const ProtectedRoute = ({ children }) => {
    const token = localStorage.getItem("token"); // ✅ Check token in localStorage
    return token ? children : <Navigate to="/auth" replace />; // If token exists, render the child component, otherwise redirect to AuthPage
  };

  // Define the routes
  const routes = [
    {
      path: "/",
      element: (
        <ProtectedRoute>
          <Home />
        </ProtectedRoute>
      ), // This will check the token before rendering the page
    },
    {
      path: "/profile/:id", // Profile route with ID parameter
      element: <UserProfile />,
      children: [
        {
          path: "posts", // Child route relative to /profile/:id
          element: <Ownpost />,
        },
      ],
    },
    {
      path: "/all-user",
      element: (
        <ProtectedRoute>
          <UserList />
        </ProtectedRoute>
      ),
    },
    {
      path: "/auth",  // Added an auth route to handle unauthenticated users
      element: <AuthPage />,
    },
  ];

  ReactDOM.createRoot(document.getElementById("root")).render(
    <React.StrictMode>
      <Router>
        <Routes>
          {routes.map((route, index) => (
            <Route key={index} path={route.path} element={route.element}>
              {route.children &&
                route.children.map((child, childIndex) => (
                  <Route
                    key={childIndex}
                    path={child.path}
                    element={child.element}
                  />
                ))}
            </Route>
          ))}
          {/* Fallback route for undefined paths */}
         
        </Routes>
      </Router>
    </React.StrictMode>
  );
