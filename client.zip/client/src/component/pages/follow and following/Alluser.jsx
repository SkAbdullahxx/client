import React, { useEffect, useState } from 'react';

const UserList = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      setLoading(true); // Show loading spinner when fetching
      try {
        const response = await fetch('http://localhost:8001/users/all-users');

        // Check if the response is ok (status code 200-299)
        if (!response.ok) {
          throw new Error('Error fetching users');
        }

        const data = await response.json();
        setUsers(data);
      } catch (error) {
        setError(error.message);
        console.error(error);
      } finally {
        setLoading(false); // Hide loading spinner after fetch
      }
    };

    fetchUsers();
  }, []);

  return (
    <div className="container mx-auto p-4">
      <h2 className="text-3xl font-semibold text-center mb-4">All Users</h2>

      {loading && (
        <div className="flex justify-center items-center">
          <div className="spinner-border animate-spin inline-block w-8 h-8 border-4 border-solid border-gray-900 rounded-full"></div>
        </div>
      )}

      {error && <div className="text-red-500 text-center mb-4">{error}</div>}

      {!loading && !error && (
        <ul className="space-y-4">
          {users.map((user) => (
            <li
              key={user._id}
              className="bg-white shadow-lg rounded-lg p-4 flex flex-col md:flex-row justify-between items-center"
            >
              <div>
                <p className="text-xl font-medium">{user.name}</p>
                <p className="text-gray-600">{user.email}</p>
              </div>
              <div>
                <button className="bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600">
                  View Profile
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      
    </div>
  );
};



export default UserList;
