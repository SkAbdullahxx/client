import React, { useState } from 'react';
import { Camera, Send } from 'lucide-react';
import axios from "axios";

const UserCreatePost = () => {
  const [postText, setPostText] = useState('');
  const [postMedia, setPostMedia] = useState(null);
  const [previewMedia, setPreviewMedia] = useState(null);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handlePostTextChange = (event) => {
    setPostText(event.target.value);
  };

  const handleMediaUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setPostMedia(file);
      setPreviewMedia(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const token = localStorage.getItem("token");

    console.log("JWT Token:", token);  // ✅ টোকেন সঠিকভাবে আসছে কিনা চেক করুন

    if (!token) {
      throw new Error("No token found! Please log in again.");
    }


    if (!postText.trim() && !postMedia) {
      setErrorMessage("⚠️ Please write something or upload media.");
      return;
    }

    setLoading(true);
    setErrorMessage('');
    setSuccessMessage('');

    try {
      const formData = new FormData();
      formData.append("content", postText);
      if (postMedia) {
        formData.append("image", postMedia);
      }

      const token = localStorage.getItem("token");  // ✅ টোকেন লোড করা

      if (!token) {
        throw new Error("No token found. Please log in.");
      }

      const response = await fetch("http://localhost:8001/posts/create", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`, // ✅ নিশ্চিত করুন 'Bearer' সহ টোকেন পাঠানো হচ্ছে
        },
        
        body: formData, 
      });
       console.log("🔹 Response Status:", response.status);
      if (!response.ok) {
        const errorData = await response.json();
        console.log("Error:", errorData);
        throw new Error(errorData.message || "Something went wrong!");
      }

      const data = await response.json();
      console.log("Success:", data);

      setSuccessMessage("✅ Your post has been uploaded successfully!");
      setPostText('');
      setPostMedia(null);
      setPreviewMedia(null);
    } catch (error) {
      setErrorMessage(`❌ Failed to upload post. Error: ${error.message}`);
      console.error("Post Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white shadow-md rounded-2xl p-5 w-full max-w-lg mx-auto">
      <form onSubmit={handleSubmit}>
        <div className="flex items-center space-x-3">
          <img
            src="https://randomuser.me/api/portraits/men/45.jpg" 
            alt="User Profile"
            className="w-12 h-12 rounded-full border-2 border-blue-500"
          />
          <textarea
            value={postText}
            onChange={handlePostTextChange}
            placeholder="What's on your mind?"
            className="w-full resize-none rounded-lg border border-gray-300 p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div className="flex justify-between items-center mt-3">
          <label htmlFor="postMediaUpload" className="flex items-center space-x-2 text-gray-600 cursor-pointer hover:text-blue-500">
            <Camera size={20} />
            <span>Add Image/Video</span>
          </label>
          <input type="file" accept="image/*,video/*" onChange={handleMediaUpload} className="hidden" id="postMediaUpload" />
        </div>
        {previewMedia && (
          <div className="mt-3">
            <img src={previewMedia} alt="Preview" className="w-full h-40 object-cover rounded-lg shadow" />
          </div>
        )}
        <button
          type="submit"
          className="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg mt-3 flex items-center justify-center space-x-2"
          disabled={loading}
        >
          {loading ? 'Posting...' : <><Send size={18} /> <span>Post</span></>}
        </button>

        {errorMessage && <p className="text-red-500 mt-2 text-center">{errorMessage}</p>}
        {successMessage && <p className="text-green-500 mt-2 text-center">{successMessage}</p>}
      </form>
    </div>
  );
};

export default UserCreatePost;
