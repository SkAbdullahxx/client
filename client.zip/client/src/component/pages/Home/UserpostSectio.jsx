import React, { useState } from "react";
import { FaHeart, FaRegHeart, FaRegComment, FaShare } from "react-icons/fa";
import { Link } from "react-router-dom";

const posts = [
  {
    id: 1,
    user: "John Doe",
    avatar: "https://i.pravatar.cc/100",
    time: "2 hours ago",
    content: "This is a sample post! Check out this beautiful image.",
    image: "https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0",
    likes: 10,
    comments: ["Nice post!", "Awesome!"],
  },
  {
    id: 2,
    user: "Jane Smith",
    avatar: "https://i.pravatar.cc/101",
    time: "5 hours ago",
    content: "Loving the weather today! ☀️",
    image: "https://images.unsplash.com/photo-1540206395-68808572332f",
    likes: 25,
    comments: ["Looks amazing!", "I wish I was there."],
  },
  {
    id: 3,
    user: "Mike Johnson",
    avatar: "https://i.pravatar.cc/102",
    time: "1 day ago",
    content: "Had a great time hiking this weekend! 🏔️",
    image: "https://images.unsplash.com/photo-1526318472351-b834d5f45d4a",
    likes: 15,
    comments: ["Wow! Stunning view.", "Nature is beautiful!"],
  },
];

const SocialMediaPost = () => {
  return (
    <div className="max-w-lg w-full mx-auto mt-10 space-y-5">
      {posts.map((post) => (
        <PostCard key={post.id} post={post} />
      ))}
    </div>
  );
};

const PostCard = ({ post }) => {
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likes);
  const [comments, setComments] = useState(post.comments);
  const [newComment, setNewComment] = useState("");
  const [showComments, setShowComments] = useState(false);

  const toggleLike = () => {
    setLiked(!liked);
    setLikeCount(liked ? likeCount - 1 : likeCount + 1);
  };

  const toggleComments = () => {
    setShowComments(!showComments);
  };

  const addComment = () => {
    if (newComment.trim() !== "") {
      setComments([...comments, newComment]);
      setNewComment("");
    }
  };

  return (
    <div className="bg-white shadow-lg rounded-lg p-5">
      {/* User Info */}
          <Link to={`/profile/${post.user}`} className="flex items-center space-x-3 mb-3 cursor-pointer">
        <img src={post.avatar} alt="User Avatar" className="w-10 h-10 rounded-full" />
        <div>
          <h3 className="font-semibold text-gray-800">{post.user}</h3>
          <p className="text-sm text-gray-500">{post.time}</p>
        </div>
      </Link>

      {/* Post Content */}
      <p className="text-gray-700 mb-3">{post.content}</p>
      <img src={post.image} alt="Post" className="rounded-lg mb-3 w-full" />

      {/* Action Buttons */}
      <div className="flex justify-between items-center text-gray-600">
        <button className="flex items-center space-x-1" onClick={toggleLike}>
          {liked ? <FaHeart className="text-xl text-red-500" /> : <FaRegHeart className="text-xl" />}
          <span>{likeCount}</span>
        </button>
        <button className="flex items-center space-x-1" onClick={toggleComments}>
          <FaRegComment className="text-xl" />
          <span>{comments.length}</span>
        </button>
        <button className="flex items-center space-x-1" onClick={() => alert("Post shared successfully!")}>
          <FaShare className="text-xl" />
          <span>Share</span>
        </button>
      </div>

      {/* Comment Section */}
      {showComments && (
        <div className="mt-4">
          <input
            type="text"
            className="w-full p-2 border rounded-md"
            placeholder="Write a comment..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
          />
          <button onClick={addComment} className="w-full bg-blue-500 text-white py-2 mt-2 rounded-md">
            Comment
          </button>
          <div className="mt-3 space-y-2 max-h-40 overflow-y-auto">
            {comments.map((comment, index) => (
              <p key={index} className="bg-gray-100 p-2 rounded-md">{comment}</p>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SocialMediaPost;
