import SocialMediaPost from "./UserpostSectio";
import UserCreatePost from "./UserCreatePost";

const PostReview = () => {
  return (
    <div className="max-w-5xl mx-auto p-4 flex gap-4 fixed top-0 left-1/2 transform -translate-x-1/2 w-full">
      {/* সাইডবার (পোস্ট তৈরি করার সেকশন) */}
      <div className="w-1/3 bg-white shadow-md rounded-lg p-4 h-fit">
        <UserCreatePost />
      </div>

      {/* মূল পোস্ট দেখানোর সেকশন */}
      <div className="w-2/3 bg-white shadow-md rounded-lg p-4 h-screen overflow-auto scrollbar-hide">
        <SocialMediaPost />
      </div>
    </div>
  );
};

export default PostReview;
