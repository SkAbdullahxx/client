import { FlameIcon } from "lucide-react";
import React, { useState, useEffect } from "react";

const UserPosts = () => {
  const [posts, setPosts] = useState([]); // State to store posts
  const [loading, setLoading] = useState(true); // State to track loading
  const [error, setError] = useState(null); // State to store error

  useEffect(() => {
    // Fetch posts from server when component mounts
    const fetchPosts = async () => {
      try {
        const response = await fetch("http://localhost:8001/posts/user/posts"); // Replace with your API endpoint
        const data = await response.json();
        setPosts(data); // Set fetched posts to state
        setLoading(false); // Set loading to false when data is fetched
      } catch (error) {
        console.error("Error fetching posts:", error);
        setError("Failed to load posts"); // Handle error
        setLoading(false);
      }
    };

    fetchPosts();
  }, []); // Empty dependency array means it runs once when component mounts

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }

  return (
    <div className="p-4">
      <h3 className="text-xl font-bold mb-4">User Posts</h3>
      {posts.length > 0 ? (
        <div className="grid grid-cols-3 gap-3">
          {posts.map((post, index) => (
            <div key={index} className="relative cursor-pointer">
              <img
                src={post.thumbnail}
                alt="Post Thumbnail"
                className="w-full h-40 object-cover rounded-lg"
              />
              <div className="absolute bottom-4 left-4 bg-black bg-opacity-50 text-white text-md font-semibold px-3 py-1 rounded-md">
                <FlameIcon />
                {post.likes ? post.likes : 0}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p>No posts available.</p>
      )}
    </div>
  );
};

// Usage
export default function ProfilePage() {
  return <UserPosts />;
}
