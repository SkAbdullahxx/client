import React from 'react';
import { useParams } from 'react-router-dom';
import SubuserPage from './Subuserpage1';
import FollowersFollow from './Followersfollow';

const Adminuser = () => {
  const { id } = useParams(); // ✅ URL থেকে User ID নিচ্ছি

  return (
    <div className="w-full h-full flex flex-col md:flex-row justify-between bg-amber-50">
      {/* ✅ SubuserPage এ props দিয়ে id পাঠাচ্ছি */}
      <SubuserPage userId={id} /> 

      <div className="w-full md:w-[36%] h-full bg-gray-100 shadow-md md:block hidden">
        <div className="flex flex-col items-center p-4">
          {/* ✅ FollowersFollow এও id পাঠাচ্ছি */}
          <FollowersFollow userId={id} />
        </div>
      </div>
    </div>
  );
};

export default Adminuser;
