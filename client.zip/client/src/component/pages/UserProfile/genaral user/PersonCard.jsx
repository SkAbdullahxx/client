import React, { useState, useMemo, useCallback } from "react";
import { motion } from "framer-motion"; // Import Framer Motion
import { FiUserCheck, FiUserPlus } from "react-icons/fi";

// Follow Button Component with Framer Motion
const FollowButton = ({ isFollowing, onClick }) => (
  <motion.button
    onClick={onClick}
    className={`flex items-center justify-center py-2 px-4 w-32 rounded-full text-white transition-all duration-300 ${
      isFollowing ? "bg-green-600 hover:bg-green-700" : "bg-blue-600 hover:bg-blue-700"
    }`}
    whileTap={{ scale: 0.9 }} // Button Press Effect
    whileHover={{ scale: 1.05 }} // Slight Hover Effect
    animate={{ backgroundColor: isFollowing ? "#16a34a" : "#2563eb", scale: [1, 1.1, 1] }} // Smooth Color Transition
    transition={{ duration: 0.3, ease: "easeInOut" }}
  >
    {isFollowing ? (
      <>
        <FiUserCheck className="mr-2" /> Following
      </>
    ) : (
      <>
        <FiUserPlus className="mr-2" /> Follow
      </>
    )}
  </motion.button>
);

// User Card Component
const UserCard = ({ user, isFollowing, onFollowClick }) => {
  const handleError = (e) => {
    e.target.src = "https://via.placeholder.com/100"; // Default fallback image
  };

  return (
    <motion.div
      className="flex items-center justify-between p-4 border-b transition-all duration-300 hover:bg-gray-100 rounded-lg shadow-sm"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
    >
      {/* Left Section (Profile Image + Username) */}
      <div className="flex items-center space-x-4">
        <img
          src={user.picture}
          alt={`${user.username}'s profile`}
          className="w-14 h-14 rounded-full object-cover border"
          onError={handleError}
        />
        <h3 className="text-lg font-semibold whitespace-nowrap">{user.username}</h3>
      </div>
      {/* Right Section (Follow Button) */}
      <FollowButton isFollowing={isFollowing} onClick={() => onFollowClick(user.id)} />
    </motion.div>
  );
};

// Main PersonCard Component
const PersonCard = () => {
  const users = useMemo(
    () => [
      { id: 1, username: "john_doe", picture: "https://randomuser.me/api/portraits/men/1.jpg" },
      { id: 2, username: "jane_smith", picture: "https://randomuser.me/api/portraits/women/2.jpg" },
      { id: 3, username: "miones_the_coder", picture: "https://randomuser.me/api/portraits/men/3.jpg" },
    ],
    []
  );

  const [following, setFollowing] = useState(new Set());

  const handleFollowClick = useCallback((userId) => {
    setFollowing((prev) => {
      const newFollowing = new Set(prev);
      newFollowing.has(userId) ? newFollowing.delete(userId) : newFollowing.add(userId);
      return newFollowing;
    });
  }, []);

  return (
    <div className="max-w-2xl mx-auto p-8">
     
      <div className="space-y-4">
        {users.map((user) => (
          <UserCard
            key={user.id}
            user={user}
            isFollowing={following.has(user.id)}
            onFollowClick={handleFollowClick}
          />
        ))}
      </div>
    </div>
  );
};

export default PersonCard;
