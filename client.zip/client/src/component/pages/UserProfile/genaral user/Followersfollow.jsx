import React, { useState } from "react";
import { motion } from "framer-motion";
import { Users, RefreshCcw } from "lucide-react";
import PersonCard from "./PersonCard";

// Component 1
const ComponentOne = () => {
  return (
    <>
    <PersonCard />
    </>
  );
};

// Component 2
const ComponentTwo = () => {
  return (
    <div className="p-4 border rounded-lg shadow-md">
      <h2 className="text-lg font-semibold">Component Number 2</h2>
      <p>This is the content for Component 2.</p>
    </div>
  );
};

const FollowersFollow = () => {
  const [activeTab, setActiveTab] = useState("followers");

  return (
    <div className="w-full flex flex-col items-center">
      {/* Tab Section */}
      <div className="relative flex justify-center items-center gap-16 p-4 border-b w-full">
        {[
          { id: "followers", label: "Followers", icon: <Users size={28} /> },
          { id: "following", label: "Following", icon: <RefreshCcw size={28} /> },
        ].map(({ id, label, icon }) => (
          <div
            key={id}
            className="relative flex flex-col items-center cursor-pointer"
            onClick={() => setActiveTab(id)}
          >
            {/* Icon & Text */}
            <motion.div
              animate={{ y: activeTab === id ? -6 : 0 }}
              transition={{ duration: 0.2 }}
              className={`text-2xl ${
                activeTab === id ? "text-blue-500" : "text-gray-500"
              }`}
            >
              {icon}
            </motion.div>
            <span className={activeTab === id ? "text-blue-500" : "text-gray-500"}>
              {label}
            </span>

            {/* Underline */}
            {activeTab === id && (
              <motion.div
                layoutId="underline"
                className="absolute bottom-0 w-full h-1 bg-blue-500 mt-1"
                initial={false}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
              />
            )}
          </div>
        ))}
      </div>

      {/* Dynamic Component Rendering with Slide Animation */}
      <motion.div
        key={activeTab} // So each change creates a new slide effect
        initial={{ x: activeTab === "followers" ? 300 : -300 }} // Start from off-screen
        animate={{ x: 0 }} // Slide to the center
        exit={{ x: activeTab === "followers" ? -300 : 300 }} // Slide off-screen when changing tabs
        transition={{ type: "spring", stiffness: 300, damping: 30 }} // Smooth spring animation
        className="mt-6"
      >
        {activeTab === "followers" ? <ComponentOne /> : <ComponentTwo />}
      </motion.div>
    </div>
  );
};

export default FollowersFollow;
