import React, { useState, useEffect } from "react";
import { motion } from "framer-motion"; 
import { Users, UserCheck, Image, MessageCircle, PlusCircle } from "lucide-react";
import ProfilePage from "./PostProfile";

const About = ({ about }) => (
  <div className="p-6 text-gray-700">
    <h3 className="text-xl font-bold mb-2">About the User</h3>
    <p>{about || "No information available."}</p>
  </div>
);

const SubuserPage = ({ userId }) => {
  const [activeTab, setActiveTab] = useState("posts");
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!userId) return;

    const fetchUserData = async () => {
      try {
        const response = await fetch(`https://api.example.com/users/${userId}`);
        if (!response.ok) throw new Error("Failed to fetch user data");
        const data = await response.json();
        setUserData(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [userId]);

  if (loading) return <div className="text-center p-4">Loading...</div>;
  if (error) return <div className="text-center p-4 text-red-500">{error}</div>;

  return (
    <div className="w-full md:w-[63%] h-full bg-white shadow-xl rounded-lg overflow-scroll">
      {/* Banner Section */}
      <div className="relative w-full h-64">
        <img
          src={userData.banner || "https://www.w3schools.com/w3images/mountains.jpg"}
          alt="Banner"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-30 backdrop-blur-sm"></div>
        <div className="absolute left-10 bottom-[-40px] flex items-center">
          <div className="w-24 h-24 md:w-32 md:h-32 rounded-full border-4 border-white shadow-lg overflow-hidden relative">
            <img
              src={userData.profile || "https://images.unsplash.com/photo-1549366029-d3d88be60e0f"}
              alt="Profile"
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-2 right-2 w-5 h-5 bg-green-500 border-2 border-white rounded-full"></div>
          </div>
          <div className="ml-4">
            <h2 className="text-3xl font-bold text-white">{userData.name}</h2>
            <p className="text-gray-300">@{userData.username}</p>
          </div>
        </div>
      </div>

      {/* User Details Section */}
      <div className="mt-16 p-6 text-center">
        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="flex flex-col items-center bg-gray-100 p-3 rounded-md shadow">
            <Users className="text-gray-700 w-6 h-6" />
            <span className="text-lg font-semibold">{userData.followers}</span>
            <span className="text-sm text-gray-600">Followers</span>
          </div>
          <div className="flex flex-col items-center bg-gray-100 p-3 rounded-md shadow">
            <UserCheck className="text-gray-700 w-6 h-6" />
            <span className="text-lg font-semibold">{userData.following}</span>
            <span className="text-sm text-gray-600">Following</span>
          </div>
          <div className="flex flex-col items-center bg-gray-100 p-3 rounded-md shadow">
            <Image className="text-gray-700 w-6 h-6" />
            <span className="text-lg font-semibold">{userData.posts}</span>
            <span className="text-sm text-gray-600">Posts</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex justify-center gap-4">
          <button className="flex items-center gap-2 bg-blue-600 text-white px-5 py-2 rounded-full shadow-md hover:bg-blue-700 transition">
            <PlusCircle className="w-5 h-5" />
            Follow
          </button>
          <button className="flex items-center gap-2 bg-gray-300 text-gray-800 px-5 py-2 rounded-full shadow-md hover:bg-gray-400 transition">
            <MessageCircle className="w-5 h-5" />
            Message
          </button>
        </div>
      </div>

      {/* Tabs Section */}
      <div className="mt-6 border-t border-gray-300">
        <div className="relative flex justify-around">
          <button
            className={`w-1/2 py-3 font-semibold ${
              activeTab === "posts" ? "text-gray-800" : "text-gray-600 hover:text-gray-800"
            }`}
            onClick={() => setActiveTab("posts")}
          >
            Posts
          </button>
          <button
            className={`w-1/2 py-3 font-semibold ${
              activeTab === "about" ? "text-gray-800" : "text-gray-600 hover:text-gray-800"
            }`}
            onClick={() => setActiveTab("about")}
          >
            About
          </button>

          {/* Smooth Underline Animation */}
          <motion.div
            className="absolute bottom-0 h-1 bg-blue-600"
            initial={{ left: "0%" }} 
            animate={{ x: activeTab === "posts" ? "0%" : "100%" }}
            transition={{ type: "spring", stiffness: 100, damping: 10 }}
            style={{ width: "50%" }}
          />
        </div>

        {/* Dynamic Content Rendering */}
        <div>{activeTab === "posts" ? <ProfilePage userId={userId} /> : <About about={userData.about} />}</div>
      </div>
    </div>
  );
};

export default SubuserPage;
