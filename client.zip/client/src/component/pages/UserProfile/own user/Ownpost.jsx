import React from 'react'

const hi = () => {
  return (
    <div>
      posts
    </div>
  )
}

export default hi