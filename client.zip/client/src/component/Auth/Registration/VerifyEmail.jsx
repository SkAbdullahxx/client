"use client";
import React, { useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom"; // Importing from react-router-dom

export default function VerifyEmail() {
  const [searchParams] = useSearchParams(); // Using useSearchParams from react-router-dom
  const navigate = useNavigate(); // Using useNavigate from react-router-dom

  // Handle form submission, verification, or other logic if needed
  const handleVerification = () => {
    // Example: Check for 'token' query param in the URL
    const token = searchParams.get("token");

    if (token) {
      // You can handle verification logic here based on token
      alert("Email verified successfully!");
      navigate("/success"); // Redirect to success page after verification
    } else {
      alert("Invalid or missing token.");
    }
  };

  return (
    <div className="flex h-screen items-center justify-center">
      <div className="w-full max-w-md text-center">
        <h2 className="text-2xl font-semibold text-emerald-500">
          Verify Your Email
        </h2>
        <p className="mt-4 text-gray-600">
          We have sent a verification link to your email. Please check your inbox.
        </p>
        <button
          onClick={handleVerification}
          className="mt-6 w-full rounded-lg bg-emerald-500 py-3 font-semibold text-white"
        >
          Verify Email
        </button>
      </div>
    </div>
  );
}
