import React, { useState } from "react";
import { Eye, EyeOff } from "lucide-react"; // Import Eye and EyeOff icons from lucide-react

export default function SignupFormFields({ formData, handleChange, handleSubmit, isLoading }) {
  const [passwordVisible, setPasswordVisible] = useState(false); // State to toggle visibility of the password

  return (
    <form className="w-full max-w-sm space-y-4">
      <input
        type="text"
        name="name"
        placeholder="Name"
        value={formData.name}
        onChange={handleChange}
        className="w-full rounded-lg bg-neutral-100 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
      />
      <input
        type="email"
        name="email"
        placeholder="Email"
        value={formData.email}
        onChange={handleChange}
        className="w-full rounded-lg bg-neutral-100 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
      />
      <div className="relative">
        <input
          type={passwordVisible ? "text" : "password"} // Toggle between 'text' and 'password' type
          name="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
          className="w-full rounded-lg bg-neutral-100 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
        />
        <button
          type="button"
          onClick={() => setPasswordVisible(!passwordVisible)} // Toggle the visibility of the password
          className="absolute right-4 top-1/2 transform -translate-y-1/2"
        >
          {passwordVisible ? (
            <EyeOff className="h-5 w-5 text-neutral-600" /> // Icon when password is visible
          ) : (
            <Eye className="h-5 w-5 text-neutral-600" /> // Icon when password is hidden
          )}
        </button>
      </div>
      <button
        type="button"
        onClick={handleSubmit}
        className="w-full rounded-lg bg-emerald-500 py-3 font-semibold text-white transition-colors hover:bg-emerald-600"
      >
        {isLoading ? "Loading..." : "NEXT"}
      </button>
    </form>
  );
}
