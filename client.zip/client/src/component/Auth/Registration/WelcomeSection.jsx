"use client"
import React from "react"
export default function WelcomeSection({ activeForm, setActiveForm }) {
  return (
    <div
      className={`absolute flex h-full w-full flex-col items-center justify-center bg-emerald-500 text-white transition-transform duration-500 ${
        activeForm !== "none" ? "translate-x-[-100%]" : "translate-x-0"
      }`}
    >
      <div className="mb-8">
        <img
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/login-form-design-04.jpg-Qv8V7Tl4jJC4lMNnw9xaHckI2WciOJ.jpeg"
          alt="Logo"
          className="h-12 w-12"
        />
      </div>
      <h1 className="mb-6 text-4xl font-bold">Welcome!</h1>
      <p className="mb-12 text-center text-lg px-4">
        To keep connected with us please login or create your account
      </p>
      <div className="flex gap-4">
        <button
          onClick={() => setActiveForm("login")}
          className="rounded-lg border-2 border-white px-12 py-2 font-semibold text-white transition-all hover:bg-white hover:text-emerald-500"
        >
          LOGIN
        </button>
        <button
          onClick={() => setActiveForm("signup")}
          className="rounded-lg border-2 border-white px-12 py-2 font-semibold text-white transition-all hover:bg-white hover:text-emerald-500"
        >
          SIGN UP
        </button>
      </div>
    </div>
  )
}
