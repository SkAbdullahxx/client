export default function EmailVerificationMessage({ setActiveForm }) {
    return (
      <div className="text-center">
        <p className="mb-4 text-neutral-600">
          A verification link has been sent to your email. Please check your inbox and click on the link to verify your email address.
        </p>
        <button
          onClick={() => setActiveForm("none")}
          className="w-full rounded-lg bg-emerald-500 py-3 font-semibold text-white transition-colors hover:bg-emerald-600"
        >
          Go to Inbox
        </button>
      </div>
    );
  }
  