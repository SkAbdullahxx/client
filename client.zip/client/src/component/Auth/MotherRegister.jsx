"use client"

import * as React from "react"
import WelcomeSection from "./Registration/WelcomeSection"
import LoginForm from "./Login/LoginForm"
import SignupForm from "./Registration/SignupForm"

export default function AuthPage() {
  const [activeForm, setActiveForm] = React.useState("none")

  return (
    <div className="flex h-screen w-full items-center justify-center bg-neutral-50 p-4">
      <div className="relative h-[600px] w-full max-w-[900px] overflow-hidden rounded-2xl bg-white shadow-2xl">
        <WelcomeSection activeForm={activeForm} setActiveForm={setActiveForm} />
        <LoginForm activeForm={activeForm} setActiveForm={setActiveForm} />
        <SignupForm activeForm={activeForm} setActiveForm={setActiveForm} />
      </div>
    </div>
  )
}

