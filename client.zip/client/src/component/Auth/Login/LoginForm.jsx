"use client";
import React, { useState } from "react";
import { Facebook, Linkedin, Eye, EyeOff } from "lucide-react"; // Import eye icons
import { useNavigate } from "react-router-dom";

export default function LoginForm({ activeForm, setActiveForm }) {
  const navigate = useNavigate(); 
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [passwordVisible, setPasswordVisible] = useState(false); // State for toggling password visibility

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(""); // Reset error before each login attempt

    try {
      const response = await fetch("http://localhost:8000/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Something went wrong");
      }

      localStorage.setItem("token", data.token); // 🔐 Save token for authentication
      console.log("Login Successful:", data);
      navigate("/profile");
      setActiveForm("none");
    } catch (err) {
      // Check if error is a network or server issue, or other specific error
      const errorMessage = err.message || "An unexpected error occurred. Please try again later.";
      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className={`absolute flex h-full w-full flex-col items-center justify-center bg-white px-8 transition-transform duration-500 ${
        activeForm === "login" ? "translate-x-0" : "translate-x-full"
      }`}
    >
      <button
        onClick={() => setActiveForm("none")}
        className="absolute left-4 top-4 text-emerald-500 hover:text-emerald-600"
      >
        ← Back
      </button>
      <h2 className="mb-8 text-4xl font-bold text-emerald-500">Welcome Back!</h2>
      
      {/* Social Login Buttons */}
      <div className="mb-8 flex gap-4">
        <button className="flex h-12 w-12 items-center justify-center rounded-full border border-neutral-300 transition-colors hover:bg-neutral-50">
          <Facebook className="h-5 w-5 text-neutral-600" />
        </button>
        <button className="flex h-12 w-12 items-center justify-center rounded-full border border-neutral-300 transition-colors hover:bg-neutral-50">
          <Linkedin className="h-5 w-5 text-neutral-600" />
        </button>
      </div>

      <p className="mb-8 text-neutral-600">or use your email to login</p>

      <form onSubmit={handleLogin} className="w-full max-w-sm space-y-4">
        {error && (
          <p className="text-red-500 mb-4 text-center">
            {error} {/* Display the error message */}
          </p>
        )}
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="w-full rounded-lg bg-neutral-100 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
        />
        <div className="relative">
          <input
            type={passwordVisible ? "text" : "password"} // Toggle between text and password type
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="w-full rounded-lg bg-neutral-100 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
          <button
            type="button"
            className="absolute right-4 top-1/2 transform -translate-y-1/2"
            onClick={() => setPasswordVisible(!passwordVisible)} // Toggle password visibility
          >
            {passwordVisible ? (
              <EyeOff className="h-5 w-5 text-neutral-600" />
            ) : (
              <Eye className="h-5 w-5 text-neutral-600" />
            )}
          </button>
        </div>
        <button
          type="submit"
          className="w-full rounded-lg bg-emerald-500 py-3 font-semibold text-white transition-colors hover:bg-emerald-600 disabled:bg-emerald-300"
          disabled={loading}
        >
          {loading ? "Logging in..." : "LOGIN"}
        </button>
      </form>
    </div>
  );
}
